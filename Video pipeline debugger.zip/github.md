repo: alektebel/barrapp
branch: claude/barra-deviation-detection-l509c9

## Last sync

date: 2026-09-08T15:26:00Z

### Updated in this project

- Built "Pipeline Debugger" — a shelf of clips with hover skeleton previews and a left-to-right stage trace.
- Stage rail, thresholds and payload keys lifted from the real modules (ingest, classify, quality, vision, process).
- Debug agent primed with the real pipeline order and threshold constants.

## Screen map

| Screen | Built from |
| --- | --- |
| Shelf (filters, previews) | server/process.py, barra/schema.py |
| Stage rail + payload diff | server/process.py (analyze_clip), barra/explain.py |
| probe / gate stages | barra/ingest.py (probe_video) |
| pose stage | barra/pose/mediapipe_backend.py |
| classify stage | barra/classify.py |
| signal / segment stages | barra/movements.py, barra/ingest.py (segment_reps_verbose, rescue_reps) |
| metrics / score stages | barra/metrics.py, barra/quality.py |
| vision stage | server/vision.py |
| Trace entries tab | barra/trace.py, docs/DEBUGGING.md |
