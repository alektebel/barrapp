export interface Rep {
  num: number
  score: number
  faults: string[]
}

export interface WorkSet {
  reps: Rep[]
}

export interface Session {
  id: string
  date: string
  exercise: string
  sets: WorkSet[]
}

export const STREAK = 18
export const XP = 2340
export const MAX_XP = 3000
export const LEVEL = 7
export const LEVEL_TITLE = 'Técnico Avanzado'

export const weekDays = [
  { label: 'L', done: true, today: false, score: 71 },
  { label: 'M', done: true, today: false, score: 78 },
  { label: 'X', done: true, today: false, score: 74 },
  { label: 'J', done: true, today: false, score: 82 },
  { label: 'V', done: false, today: true, score: undefined },
  { label: 'S', done: false, today: false, score: undefined },
  { label: 'D', done: false, today: false, score: undefined },
]

export const mockSessions: Session[] = [
  {
    id: 's1',
    date: '2026-09-04',
    exercise: 'Pull-up',
    sets: [
      {
        reps: [
          { num: 1, score: 91, faults: [] },
          { num: 2, score: 88, faults: [] },
          { num: 3, score: 82, faults: ['Codo abierto al final'] },
          { num: 4, score: 75, faults: ['Codo abierto al final'] },
          { num: 5, score: 71, faults: ['ROM incompleto — arriba'] },
          { num: 6, score: 63, faults: ['Codo abierto al final', 'Balanceo'] },
          { num: 7, score: 52, faults: ['Balanceo', 'ROM incompleto — arriba'] },
          { num: 8, score: 44, faults: ['Balanceo', 'ROM incompleto — arriba'] },
        ],
      },
      {
        reps: [
          { num: 1, score: 84, faults: [] },
          { num: 2, score: 79, faults: [] },
          { num: 3, score: 74, faults: ['Codo abierto al final'] },
          { num: 4, score: 68, faults: ['Codo abierto al final'] },
          { num: 5, score: 61, faults: ['ROM incompleto — arriba'] },
          { num: 6, score: 53, faults: ['Balanceo', 'ROM incompleto — arriba'] },
        ],
      },
      {
        reps: [
          { num: 1, score: 78, faults: [] },
          { num: 2, score: 72, faults: ['Codo abierto al final'] },
          { num: 3, score: 65, faults: ['Codo abierto al final'] },
          { num: 4, score: 58, faults: ['Balanceo'] },
          { num: 5, score: 49, faults: ['Balanceo', 'ROM incompleto — arriba'] },
        ],
      },
    ],
  },
  {
    id: 's2',
    date: '2026-09-03',
    exercise: 'Pull-up',
    sets: [
      {
        reps: [
          { num: 1, score: 88, faults: [] },
          { num: 2, score: 85, faults: [] },
          { num: 3, score: 80, faults: [] },
          { num: 4, score: 72, faults: ['Codo abierto al final'] },
          { num: 5, score: 68, faults: ['Codo abierto al final'] },
          { num: 6, score: 60, faults: ['Balanceo'] },
          { num: 7, score: 54, faults: ['Balanceo', 'ROM incompleto — arriba'] },
        ],
      },
      {
        reps: [
          { num: 1, score: 81, faults: [] },
          { num: 2, score: 76, faults: [] },
          { num: 3, score: 71, faults: ['Codo abierto al final'] },
          { num: 4, score: 65, faults: ['Codo abierto al final'] },
          { num: 5, score: 58, faults: ['Balanceo'] },
          { num: 6, score: 50, faults: ['Balanceo', 'ROM incompleto — arriba'] },
        ],
      },
    ],
  },
]

export const qualityTrend = [
  { label: '9 Ag', score: 58 },
  { label: '11 Ag', score: 61 },
  { label: '13 Ag', score: 59 },
  { label: '15 Ag', score: 64 },
  { label: '17 Ag', score: 62 },
  { label: '19 Ag', score: 67 },
  { label: '21 Ag', score: 65 },
  { label: '23 Ag', score: 70 },
  { label: '25 Ag', score: 68 },
  { label: '27 Ag', score: 72 },
  { label: '29 Ag', score: 71 },
  { label: '31 Ag', score: 75 },
  { label: '2 Sep', score: 73 },
  { label: '4 Sep', score: 74 },
  { label: '6 Sep', score: 78 },
  { label: '8 Sep', score: 76 },
]

export const personalBests = [
  { exercise: 'Pull-up', metric: 'Calidad media', value: '82', unit: 'pts', date: '27 Ago' },
  { exercise: 'Pull-up', metric: 'Serie más limpia', value: '9', unit: 'reps', date: '31 Ago' },
  { exercise: 'Muscle-up', metric: 'Rep más limpia', value: '91', unit: 'pts', date: '15 Ago' },
]

export const faultTrend = [
  { fault: 'Codo abierto al final', count: 28, trend: -4, color: '#f59e0b' },
  { fault: 'Balanceo', count: 19, trend: -7, color: '#22d3a5' },
  { fault: 'ROM incompleto — arriba', count: 14, trend: -2, color: '#7c5dfa' },
  { fault: 'Extensión incompleta', count: 6, trend: -3, color: '#22d3a5' },
]

export const coachTips = [
  {
    fault: 'Codo abierto al final',
    exercise: 'Pull-up',
    severity: 'alta',
    cue: 'Imagina que quieres meter los codos en los bolsillos traseros del pantalón.',
    drill: 'Band-assisted chin-up con foco en la contracción del dorsal',
    repsAffected: 28,
    improvementPct: 14,
    imageUrl: 'https://images.unsplash.com/photo-1597347316205-36f6c451902a?w=600&h=400&fit=crop&auto=format',
  },
  {
    fault: 'Balanceo',
    exercise: 'Pull-up',
    severity: 'media',
    cue: 'Activa el core antes de subir. Pies juntos, glúteos apretados.',
    drill: 'Dead hang estático 3×30 s antes de tu serie',
    repsAffected: 19,
    improvementPct: 37,
    imageUrl: 'https://images.unsplash.com/photo-1682048682610-20a91f10b29c?w=600&h=400&fit=crop&auto=format',
  },
]

export function scoreColor(score: number): string {
  if (score >= 85) return '#22d3a5'
  if (score >= 70) return '#7c5dfa'
  if (score >= 55) return '#f59e0b'
  return '#f43f5e'
}

export function scoreLabel(score: number): string {
  if (score >= 85) return 'Perfecto'
  if (score >= 70) return 'Bueno'
  if (score >= 55) return 'Mejorable'
  return 'Fatiga'
}

export function sessionAvg(session: Session): number {
  const all = session.sets.flatMap(s => s.reps)
  return Math.round(all.reduce((a, r) => a + r.score, 0) / all.length)
}

export function setAvg(set: WorkSet): number {
  return Math.round(set.reps.reduce((a, r) => a + r.score, 0) / set.reps.length)
}
