import { useState } from 'react'
import type { Profile } from '../App'

const exercises = ['Pull-up', 'Muscle-up', 'Dip', 'L-Sit', 'Handstand']
const goals = [
  { id: 'form', label: 'Perfeccionar técnica', sub: 'Cada rep más limpia que la anterior' },
  { id: 'strength', label: 'Ganar fuerza', sub: 'Más reps, mejor calidad, semana a semana' },
  { id: 'compete', label: 'Competir', sub: 'Llevar el rendimiento al límite' },
]
const levels = [
  { id: 'beginner', label: 'Principiante', sub: 'Menos de 5 reps de pull-up' },
  { id: 'intermediate', label: 'Intermedio', sub: '5–12 reps limpias' },
  { id: 'advanced', label: 'Avanzado', sub: 'Muscle-up o más' },
]

interface Step {
  step: number
  total: number
}

function ProgressDots({ step, total }: Step) {
  return (
    <div className="flex gap-1.5 mb-8">
      {Array.from({ length: total }).map((_, i) => (
        <div
          key={i}
          className="rounded-full transition-all duration-400"
          style={{
            width: i === step ? 20 : 6,
            height: 6,
            background: i <= step ? '#7c5dfa' : '#2a2a44',
          }}
        />
      ))}
    </div>
  )
}

function ChoiceCard({
  label,
  sub,
  selected,
  onClick,
}: {
  label: string
  sub?: string
  selected: boolean
  onClick: () => void
}) {
  return (
    <button
      onClick={onClick}
      className="w-full text-left rounded-2xl px-4 py-3.5 mb-3 transition-all duration-200"
      style={{
        background: selected ? 'rgba(124,93,250,0.18)' : '#161626',
        border: `1.5px solid ${selected ? '#7c5dfa' : '#2a2a44'}`,
        transform: selected ? 'scale(1.02)' : 'scale(1)',
      }}
    >
      <div className="flex items-center justify-between">
        <div>
          <p className="font-display text-lg font-bold uppercase text-[#f0eeff] tracking-wide">{label}</p>
          {sub && <p className="text-xs text-[#7070a0] mt-0.5">{sub}</p>}
        </div>
        <div
          className="w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition-all"
          style={{ borderColor: selected ? '#7c5dfa' : '#2a2a44', background: selected ? '#7c5dfa' : 'transparent' }}
        >
          {selected && (
            <svg width="10" height="10" viewBox="0 0 10 10">
              <polyline points="2,5 4,7.5 8,2.5" stroke="white" strokeWidth="1.8" fill="none" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          )}
        </div>
      </div>
    </button>
  )
}

export default function Onboarding({ onComplete }: { onComplete: (p: Profile) => void }) {
  const [step, setStep] = useState(0)
  const [name, setName] = useState('')
  const [exercise, setExercise] = useState('')
  const [goal, setGoal] = useState('')
  const [level, setLevel] = useState('')
  const [showBriefing, setShowBriefing] = useState(false)

  const canNext =
    (step === 0 && name.trim().length > 0) ||
    (step === 1 && exercise) ||
    (step === 2 && goal) ||
    (step === 3 && level)

  function next() {
    if (step < 3) setStep(step + 1)
    else setShowBriefing(true)
  }

  function startTraining() {
    onComplete({ name: name.trim(), exercise, goal, level })
  }

  if (showBriefing) {
    return (
      <div className="h-full flex flex-col items-center justify-center px-6 text-center" style={{ background: '#0b0b12' }}>
        <div className="animate-fade-in">
          <div
            className="w-20 h-20 rounded-3xl mx-auto mb-6 flex items-center justify-center text-4xl animate-badge-pop"
            style={{ background: 'rgba(124,93,250,0.15)', border: '1.5px solid rgba(124,93,250,0.4)' }}
          >
            🎯
          </div>
          <p className="font-mono-data text-[10px] text-[#7c5dfa] uppercase tracking-[0.2em] mb-3 animate-slide-up delay-200">
            MISIÓN ASIGNADA
          </p>
          <h1 className="font-display text-4xl font-black uppercase text-[#f0eeff] leading-tight mb-2 animate-slide-up delay-300">
            BIENVENIDO,<br />{name.toUpperCase()}
          </h1>
          <p className="text-[#7070a0] text-sm leading-relaxed mb-8 animate-slide-up delay-400">
            Ejercicio principal: <span className="text-[#a78bfa] font-semibold">{exercise}</span>
            <br />
            Objetivo: <span className="text-[#a78bfa] font-semibold">{goals.find(g => g.id === goal)?.label}</span>
          </p>
          <div
            className="rounded-2xl px-5 py-3 mb-8 animate-slide-up delay-500"
            style={{ background: '#161626', border: '1px solid #2a2a44' }}
          >
            <p className="text-xs text-[#7070a0]">
              BarrApp analizará cada rep que filmes y te dirá exactamente qué corregir.
              Sin adivinanzas. Sin opiniones. Solo datos.
            </p>
          </div>
          <button
            onClick={startTraining}
            className="w-full py-4 rounded-2xl font-display text-xl font-black uppercase tracking-widest text-white animate-slide-up delay-600 transition-transform active:scale-[0.98]"
            style={{ background: 'linear-gradient(135deg, #7c5dfa, #a78bfa)' }}
          >
            EMPEZAR A ENTRENAR
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="h-full flex flex-col px-6 pt-14" style={{ background: '#0b0b12' }}>
      {/* Logo */}
      <div className="flex items-center gap-2 mb-10">
        <div
          className="w-8 h-8 rounded-lg flex items-center justify-center"
          style={{ background: 'rgba(124,93,250,0.2)', border: '1px solid rgba(124,93,250,0.4)' }}
        >
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
            <line x1="4" y1="8" x2="12" y2="8" stroke="#7c5dfa" strokeWidth="2.5" strokeLinecap="round" />
            <path d="M4 12 C5.5 12 6 6 8 6 C10 6 10.5 12 12 12" fill="none" stroke="#a78bfa" strokeWidth="2" strokeLinecap="round" />
          </svg>
        </div>
        <span className="font-display text-xl font-black tracking-wider text-[#f0eeff]">BARRAPP</span>
      </div>

      <ProgressDots step={step} total={4} />

      {step === 0 && (
        <div className="animate-slide-up flex-1">
          <p className="font-mono-data text-[10px] text-[#7c5dfa] uppercase tracking-[0.2em] mb-3">PASO 1 DE 4</p>
          <h2 className="font-display text-4xl font-black uppercase text-[#f0eeff] leading-tight mb-2">
            ¿CÓMO TE<br />LLAMAMOS?
          </h2>
          <p className="text-sm text-[#7070a0] mb-8">Tu nombre aparecerá en tus logros y en el ranking.</p>
          <div
            className="rounded-2xl px-4 py-3.5 mb-3"
            style={{ background: '#161626', border: '1.5px solid #2a2a44' }}
          >
            <input
              type="text"
              placeholder="Tu nombre…"
              value={name}
              onChange={e => setName(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && canNext && next()}
              className="w-full font-display text-2xl font-bold uppercase text-[#f0eeff] placeholder-[#3a3a58] tracking-wide"
              style={{ fontFamily: "'Barlow Condensed', sans-serif" }}
              autoFocus
            />
          </div>
        </div>
      )}

      {step === 1 && (
        <div className="animate-slide-up flex-1">
          <p className="font-mono-data text-[10px] text-[#7c5dfa] uppercase tracking-[0.2em] mb-3">PASO 2 DE 4</p>
          <h2 className="font-display text-4xl font-black uppercase text-[#f0eeff] leading-tight mb-2">
            TU MOVIMIENTO<br />PRINCIPAL
          </h2>
          <p className="text-sm text-[#7070a0] mb-6">El coach ajustará el análisis a este ejercicio.</p>
          {exercises.map(ex => (
            <ChoiceCard key={ex} label={ex} selected={exercise === ex} onClick={() => setExercise(ex)} />
          ))}
        </div>
      )}

      {step === 2 && (
        <div className="animate-slide-up flex-1">
          <p className="font-mono-data text-[10px] text-[#7c5dfa] uppercase tracking-[0.2em] mb-3">PASO 3 DE 4</p>
          <h2 className="font-display text-4xl font-black uppercase text-[#f0eeff] leading-tight mb-2">
            ¿QUÉ QUIERES<br />CONSEGUIR?
          </h2>
          <p className="text-sm text-[#7070a0] mb-6">Define tu objetivo ahora. Puedes cambiarlo más adelante.</p>
          {goals.map(g => (
            <ChoiceCard key={g.id} label={g.label} sub={g.sub} selected={goal === g.id} onClick={() => setGoal(g.id)} />
          ))}
        </div>
      )}

      {step === 3 && (
        <div className="animate-slide-up flex-1">
          <p className="font-mono-data text-[10px] text-[#7c5dfa] uppercase tracking-[0.2em] mb-3">PASO 4 DE 4</p>
          <h2 className="font-display text-4xl font-black uppercase text-[#f0eeff] leading-tight mb-2">
            TU NIVEL<br />ACTUAL
          </h2>
          <p className="text-sm text-[#7070a0] mb-6">Sé honesto — solo sirve para calibrar el punto de partida.</p>
          {levels.map(l => (
            <ChoiceCard key={l.id} label={l.label} sub={l.sub} selected={level === l.id} onClick={() => setLevel(l.id)} />
          ))}
        </div>
      )}

      <div className="pb-8 mt-4">
        <button
          onClick={next}
          disabled={!canNext}
          className="w-full py-4 rounded-2xl font-display text-xl font-black uppercase tracking-widest text-white transition-all duration-200 active:scale-[0.98]"
          style={{
            background: canNext ? 'linear-gradient(135deg, #7c5dfa, #a78bfa)' : '#1e1e32',
            color: canNext ? 'white' : '#7070a0',
          }}
        >
          {step < 3 ? 'SIGUIENTE' : 'VER MI MISIÓN'}
        </button>
      </div>
    </div>
  )
}
