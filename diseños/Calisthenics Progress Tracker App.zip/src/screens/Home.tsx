import { useEffect, useState } from 'react'
import type { Profile } from '../App'
import {
  STREAK, XP, MAX_XP, LEVEL, LEVEL_TITLE,
  weekDays, mockSessions, scoreColor, scoreLabel, sessionAvg, setAvg,
} from '../data/mock'

export default function Home({ profile }: { profile: Profile }) {
  const [xpReady, setXpReady] = useState(false)

  useEffect(() => {
    const t = setTimeout(() => setXpReady(true), 350)
    return () => clearTimeout(t)
  }, [])

  const session = mockSessions[0]
  const allReps = session.sets.flatMap(s => s.reps)
  const avg = sessionAvg(session)
  const totalReps = allReps.length

  const faultMap: Record<string, number> = {}
  allReps.forEach(r => r.faults.forEach(f => { faultMap[f] = (faultMap[f] || 0) + 1 }))
  const topFault = Object.entries(faultMap).sort((a, b) => b[1] - a[1])[0]

  const badges = [
    { label: '18 días seguidos', icon: '🔥', unlocked: true },
    { label: 'Serie perfecta', icon: '💎', unlocked: true },
    { label: '100 pull-ups', icon: '💪', unlocked: true },
    { label: 'Muscle-up', icon: '👑', unlocked: false },
  ]

  return (
    <div className="px-4 pb-6 space-y-4 pt-2">
      {/* Greeting + Streak */}
      <div className="flex items-start justify-between">
        <div>
          <p className="font-mono-data text-[10px] text-[#7070a0] uppercase tracking-[0.18em]">Buenas,</p>
          <h1
            className="font-display text-[38px] font-black uppercase leading-none text-[#f0eeff]"
            style={{ letterSpacing: '0.02em' }}
          >
            {profile.name}
          </h1>
          <div className="flex items-center gap-2 mt-0.5">
            <span className="font-mono-data text-[10px] text-[#7c5dfa] uppercase tracking-wider">Lv.{LEVEL}</span>
            <span className="text-[#2a2a44]">·</span>
            <span className="font-mono-data text-[10px] text-[#7070a0]">{LEVEL_TITLE}</span>
          </div>
        </div>

        <div className="flex flex-col items-center">
          <div
            className="w-14 h-14 rounded-2xl flex flex-col items-center justify-center relative overflow-hidden"
            style={{ background: 'rgba(245,158,11,0.1)', border: '1.5px solid rgba(245,158,11,0.25)' }}
          >
            <span className="text-2xl animate-streak-flame">🔥</span>
          </div>
          <span className="font-display text-2xl font-black text-[#f59e0b] leading-tight">{STREAK}</span>
          <span className="font-mono-data text-[8px] text-[#7070a0] uppercase tracking-wider">RACHA</span>
        </div>
      </div>

      {/* XP Bar */}
      <div
        className="rounded-2xl p-4"
        style={{ background: '#161626', border: '1px solid #2a2a44' }}
      >
        <div className="flex justify-between items-center mb-2">
          <span className="font-mono-data text-[10px] text-[#7070a0] uppercase tracking-wider">XP AL SIGUIENTE NIVEL</span>
          <span className="font-mono-data text-[10px] text-[#a78bfa]">{XP.toLocaleString()} / {MAX_XP.toLocaleString()}</span>
        </div>
        <div className="h-1.5 rounded-full overflow-hidden" style={{ background: '#2a2a44' }}>
          <div
            className="h-full rounded-full transition-all duration-1000 ease-out"
            style={{
              width: xpReady ? `${(XP / MAX_XP) * 100}%` : '0%',
              background: 'linear-gradient(90deg, #7c5dfa, #a78bfa)',
            }}
          />
        </div>
        <p className="text-[9px] text-[#7070a0] mt-1.5">
          {MAX_XP - XP} XP para nivel {LEVEL + 1} — <span className="text-[#a78bfa]">Maestro de Técnica</span>
        </p>
      </div>

      {/* Mission card */}
      <div
        className="rounded-2xl p-4"
        style={{ background: '#161626', border: '1.5px solid rgba(124,93,250,0.3)' }}
      >
        <div className="flex items-center gap-2 mb-3">
          <div className="w-1 h-4 rounded-full" style={{ background: '#7c5dfa' }} />
          <span className="font-mono-data text-[10px] text-[#7c5dfa] uppercase tracking-[0.15em]">MISIÓN DE HOY</span>
        </div>
        <p className="font-display text-xl font-bold uppercase text-[#f0eeff] tracking-wide mb-0.5">
          3 Series · {profile.exercise}
        </p>
        <p className="text-xs text-[#7070a0] mb-4">Foco: mantener codos cerrados durante todo el recorrido</p>
        <div className="flex gap-2 mb-2">
          {[1, 2, 3].map(i => (
            <div
              key={i}
              className="flex-1 h-1.5 rounded-full transition-all duration-500"
              style={{ background: i <= 2 ? '#7c5dfa' : '#2a2a44' }}
            />
          ))}
        </div>
        <p className="font-mono-data text-[9px] text-[#7070a0]">2 de 3 series completadas · +120 XP al terminar</p>
      </div>

      {/* Weekly calendar */}
      <div className="rounded-2xl p-4" style={{ background: '#161626', border: '1px solid #2a2a44' }}>
        <span className="font-mono-data text-[10px] text-[#7070a0] uppercase tracking-wider">ESTA SEMANA</span>
        <div className="flex justify-between mt-3">
          {weekDays.map((d, i) => (
            <div key={i} className="flex flex-col items-center gap-1.5">
              <span className="font-mono-data text-[9px] text-[#7070a0] uppercase">{d.label}</span>
              <div
                className="w-8 h-8 rounded-full flex items-center justify-center transition-all"
                style={{
                  background: d.done ? '#7c5dfa' : d.today ? 'transparent' : '#1e1e32',
                  border: d.today ? '1.5px solid rgba(124,93,250,0.5)' : 'none',
                }}
              >
                {d.done ? (
                  <svg width="12" height="12" viewBox="0 0 12 12">
                    <polyline points="2,6 5,9 10,3" stroke="white" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                ) : d.today ? (
                  <div className="w-1.5 h-1.5 rounded-full" style={{ background: '#7c5dfa' }} />
                ) : null}
              </div>
              {d.score !== undefined && (
                <span className="font-mono-data text-[8px]" style={{ color: scoreColor(d.score) }}>
                  {d.score}
                </span>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Last session */}
      <div className="rounded-2xl p-4" style={{ background: '#161626', border: '1px solid #2a2a44' }}>
        <div className="flex justify-between items-start mb-3">
          <div>
            <span className="font-mono-data text-[10px] text-[#7070a0] uppercase tracking-wider">ÚLTIMA SESIÓN</span>
            <p className="font-display text-xl font-bold uppercase text-[#f0eeff]">{session.exercise}</p>
            <p className="text-xs text-[#7070a0]">{session.sets.length} series · {totalReps} reps</p>
          </div>
          <div className="text-right">
            <span
              className="font-display text-4xl font-black leading-none"
              style={{ color: scoreColor(avg) }}
            >
              {avg}
            </span>
            <p className="font-mono-data text-[8px] text-[#7070a0] uppercase mt-0.5">CALIDAD MEDIA</p>
            <p className="font-mono-data text-[8px] mt-0.5" style={{ color: scoreColor(avg) }}>
              {scoreLabel(avg)}
            </p>
          </div>
        </div>

        <div className="space-y-2 mb-3">
          {session.sets.map((set, si) => {
            const sa = setAvg(set)
            return (
              <div key={si} className="flex items-center gap-2.5">
                <span className="font-mono-data text-[9px] text-[#7070a0] w-9 flex-shrink-0">SER {si + 1}</span>
                <div className="flex-1 h-1 rounded-full overflow-hidden" style={{ background: '#2a2a44' }}>
                  <div
                    className="h-full rounded-full"
                    style={{ width: `${sa}%`, background: scoreColor(sa) }}
                  />
                </div>
                <span className="font-mono-data text-[9px] w-6 text-right flex-shrink-0" style={{ color: scoreColor(sa) }}>
                  {sa}
                </span>
                <span className="font-mono-data text-[8px] text-[#7070a0] w-10 flex-shrink-0">
                  {set.reps.length} reps
                </span>
              </div>
            )
          })}
        </div>

        {topFault && (
          <div
            className="flex items-center gap-2.5 rounded-xl px-3 py-2.5"
            style={{ background: 'rgba(245,158,11,0.08)', border: '1px solid rgba(245,158,11,0.2)' }}
          >
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
              <path d="M7 1.5L13 12.5H1L7 1.5Z" stroke="#f59e0b" strokeWidth="1.5" fill="none" strokeLinecap="round" strokeLinejoin="round" />
              <line x1="7" y1="5.5" x2="7" y2="8.5" stroke="#f59e0b" strokeWidth="1.5" strokeLinecap="round" />
              <circle cx="7" cy="10.5" r="0.7" fill="#f59e0b" />
            </svg>
            <span className="text-xs text-[#f59e0b]">
              {topFault[0]} · {topFault[1]} reps afectadas
            </span>
            <span className="ml-auto font-mono-data text-[9px] text-[#7070a0]">VER COACH →</span>
          </div>
        )}
      </div>

      {/* Badges */}
      <div className="rounded-2xl p-4" style={{ background: '#161626', border: '1px solid #2a2a44' }}>
        <div className="flex items-center justify-between mb-3">
          <span className="font-mono-data text-[10px] text-[#7070a0] uppercase tracking-wider">LOGROS</span>
          <span className="font-mono-data text-[9px] text-[#7c5dfa]">VER TODOS</span>
        </div>
        <div className="flex gap-3">
          {badges.map((b, i) => (
            <div key={i} className="flex flex-col items-center gap-1.5 flex-1">
              <div
                className="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl transition-all"
                style={{
                  background: b.unlocked ? 'rgba(124,93,250,0.12)' : '#1a1a26',
                  border: `1px solid ${b.unlocked ? 'rgba(124,93,250,0.3)' : '#2a2a44'}`,
                  opacity: b.unlocked ? 1 : 0.35,
                }}
              >
                {b.icon}
              </div>
              <span
                className="font-mono-data text-[7px] text-center leading-tight"
                style={{ color: b.unlocked ? '#7070a0' : '#3a3a58' }}
              >
                {b.label}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
