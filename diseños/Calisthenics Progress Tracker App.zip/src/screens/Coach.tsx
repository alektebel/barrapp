import { useState } from 'react'
import { coachTips } from '../data/mock'

const techniqueRules = [
  {
    id: 'elbow',
    title: 'Codos adentro',
    phase: 'Tirón / fase concéntrica',
    verdict: 'Corregir',
    verdictColor: '#f59e0b',
    description: 'Los codos se abren lateralmente en el punto de mayor esfuerzo, lo que reduce la activación del dorsal y sobrecarga los bíceps.',
    cue: 'Imagina que quieres meter los codos en los bolsillos traseros.',
    canCheck: true,
  },
  {
    id: 'rom',
    title: 'ROM completo arriba',
    phase: 'Bloqueo superior',
    verdict: 'Corregir',
    verdictColor: '#f59e0b',
    description: 'La barbilla no supera la barra en algunas reps, lo que impide la activación completa del trapecio inferior.',
    cue: 'Aprieta la espalda alta y aguanta 0.5 s con la barbilla por encima de la barra.',
    canCheck: true,
  },
  {
    id: 'swing',
    title: 'Sin balanceo',
    phase: 'Toda la serie',
    verdict: 'Progresando',
    verdictColor: '#22d3a5',
    description: 'El balanceo transfiere inercia a las caderas y reduce el trabajo muscular real. Mejorando semana a semana.',
    cue: 'Activa glúteos y core antes de despegar. Pies juntos, cuerpo rígido.',
    canCheck: false,
  },
  {
    id: 'extension',
    title: 'Extensión completa abajo',
    phase: 'Fase excéntrica',
    verdict: 'Correcto',
    verdictColor: '#a78bfa',
    description: 'Buena extensión en la fase negativa. Sigue así — protege los tendones del manguito.',
    cue: 'Llega siempre al dead hang completo entre reps.',
    canCheck: false,
  },
]

const drills = [
  {
    title: 'Scapular pull-up',
    sets: '3×8',
    focus: 'Activación del dorsal sin doblar el codo',
    duration: '4 min',
  },
  {
    title: 'Band-assisted chin-up',
    sets: '3×5',
    focus: 'Codos adentro con resistencia reducida',
    duration: '6 min',
  },
  {
    title: 'Dead hang estático',
    sets: '3×30 s',
    focus: 'Fuerza de agarre y core anti-balanceo',
    duration: '3 min',
  },
]

export default function Coach({ exercise }: { exercise: string }) {
  const [expandedRule, setExpandedRule] = useState<string | null>('elbow')
  const [expandedTip, setExpandedTip] = useState<number | null>(0)

  return (
    <div className="px-4 pb-6 space-y-4 pt-2">
      <div>
        <p className="font-mono-data text-[10px] text-[#7070a0] uppercase tracking-[0.18em]">BarrApp</p>
        <h1 className="font-display text-3xl font-black uppercase text-[#f0eeff] leading-none">COACH</h1>
        <p className="text-xs text-[#7070a0] mt-0.5">Basado en tus últimas 4 sesiones de {exercise}</p>
      </div>

      {/* Today's focus */}
      <div
        className="rounded-2xl overflow-hidden animate-slide-up"
        style={{ border: '1.5px solid rgba(124,93,250,0.3)' }}
      >
        <div className="relative h-36">
          <img
            src={coachTips[0].imageUrl}
            alt="Pull-up technique"
            className="w-full h-full object-cover"
            style={{ filter: 'brightness(0.45)' }}
          />
          <div className="absolute inset-0 p-4 flex flex-col justify-end">
            <div className="flex items-center gap-2 mb-1">
              <div className="w-1.5 h-4 rounded-full" style={{ background: '#f59e0b' }} />
              <span className="font-mono-data text-[9px] text-[#f59e0b] uppercase tracking-[0.15em]">FOCO DE HOY</span>
            </div>
            <p className="font-display text-2xl font-black uppercase text-white leading-tight">
              {coachTips[0].fault}
            </p>
            <p className="text-xs text-white/70 mt-0.5">
              {coachTips[0].repsAffected} reps afectadas · ↓ {coachTips[0].improvementPct}% en 4 semanas
            </p>
          </div>
        </div>
        <div className="p-4" style={{ background: '#161626' }}>
          <p className="text-xs text-[#7070a0] mb-3">{coachTips[0].cue}</p>
          <div
            className="flex items-center gap-2.5 rounded-xl px-3 py-2.5"
            style={{ background: 'rgba(124,93,250,0.1)', border: '1px solid rgba(124,93,250,0.2)' }}
          >
            <span className="text-lg">🏋️</span>
            <div>
              <p className="text-xs font-semibold text-[#f0eeff]">Ejercicio correctivo</p>
              <p className="text-[10px] text-[#a78bfa]">{coachTips[0].drill}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Technique rules */}
      <div
        className="rounded-2xl overflow-hidden animate-slide-up delay-100"
        style={{ background: '#161626', border: '1px solid #2a2a44' }}
      >
        <div className="px-4 pt-4 pb-2">
          <span className="font-mono-data text-[10px] text-[#7070a0] uppercase tracking-wider">REGLAS DE TÉCNICA · {exercise.toUpperCase()}</span>
          <p className="text-[9px] text-[#7070a0] mt-0.5">El sistema evalúa estos criterios en cada rep</p>
        </div>
        {techniqueRules.map((rule, i) => (
          <div key={rule.id} style={{ borderTop: '1px solid #2a2a44' }}>
            <button
              onClick={() => setExpandedRule(expandedRule === rule.id ? null : rule.id)}
              className="w-full px-4 py-3 flex items-center justify-between text-left"
            >
              <div className="flex items-center gap-3">
                <div
                  className="w-2 h-2 rounded-full flex-shrink-0"
                  style={{ background: rule.verdictColor }}
                />
                <div>
                  <p className="text-sm font-semibold text-[#f0eeff]">{rule.title}</p>
                  <p className="font-mono-data text-[9px] text-[#7070a0]">{rule.phase}</p>
                </div>
              </div>
              <div className="flex items-center gap-2.5">
                <span className="font-mono-data text-[9px]" style={{ color: rule.verdictColor }}>
                  {rule.verdict}
                </span>
                <svg
                  width="14"
                  height="14"
                  viewBox="0 0 14 14"
                  fill="none"
                  style={{ transform: expandedRule === rule.id ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }}
                >
                  <path d="M3 5l4 4 4-4" stroke="#7070a0" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </div>
            </button>
            {expandedRule === rule.id && (
              <div className="px-4 pb-4 animate-fade-in">
                <p className="text-xs text-[#7070a0] mb-2 leading-relaxed">{rule.description}</p>
                <div
                  className="rounded-xl px-3 py-2.5 flex items-start gap-2"
                  style={{ background: 'rgba(124,93,250,0.08)', border: '1px solid rgba(124,93,250,0.15)' }}
                >
                  <span className="text-[#a78bfa] text-base">💡</span>
                  <p className="text-xs text-[#a78bfa] leading-relaxed">{rule.cue}</p>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Today's drills */}
      <div
        className="rounded-2xl p-4 animate-slide-up delay-200"
        style={{ background: '#161626', border: '1px solid #2a2a44' }}
      >
        <div className="flex items-center justify-between mb-4">
          <span className="font-mono-data text-[10px] text-[#7070a0] uppercase tracking-wider">EJERCICIOS CORRECTIVOS DE HOY</span>
          <span className="font-mono-data text-[9px] text-[#7070a0]">~13 min</span>
        </div>
        {drills.map((d, i) => (
          <div
            key={i}
            className="flex items-start gap-3 py-3"
            style={{ borderBottom: i < drills.length - 1 ? '1px solid #2a2a44' : 'none' }}
          >
            <div
              className="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 font-display font-black text-sm"
              style={{ background: 'rgba(124,93,250,0.15)', color: '#a78bfa' }}
            >
              {i + 1}
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <p className="text-sm font-semibold text-[#f0eeff]">{d.title}</p>
                <span className="font-mono-data text-[9px] text-[#7c5dfa]">{d.sets}</span>
              </div>
              <p className="text-[10px] text-[#7070a0] mt-0.5">{d.focus}</p>
              <p className="font-mono-data text-[9px] text-[#2a2a44] mt-0.5">{d.duration}</p>
            </div>
          </div>
        ))}
        <button
          className="w-full py-3.5 rounded-xl font-display text-lg font-bold uppercase tracking-widest mt-3 active:scale-[0.98] transition-transform"
          style={{ background: 'rgba(124,93,250,0.12)', color: '#a78bfa', border: '1.5px solid rgba(124,93,250,0.25)' }}
        >
          EMPEZAR RUTINA CORRECTIVA
        </button>
      </div>

      {/* Second fault tip */}
      <div
        className="rounded-2xl overflow-hidden animate-slide-up delay-300"
        style={{ background: '#161626', border: '1px solid #2a2a44' }}
      >
        <button
          onClick={() => setExpandedTip(expandedTip === 1 ? null : 1)}
          className="w-full"
        >
          <div className="relative h-28">
            <img
              src={coachTips[1].imageUrl}
              alt="Balanceo technique"
              className="w-full h-full object-cover"
              style={{ filter: 'brightness(0.4)' }}
            />
            <div className="absolute inset-0 p-4 flex flex-col justify-between">
              <div className="flex items-center gap-2">
                <div className="w-1.5 h-4 rounded-full" style={{ background: '#22d3a5' }} />
                <span className="font-mono-data text-[9px] text-[#22d3a5] uppercase tracking-[0.12em]">MEJORANDO</span>
              </div>
              <div className="flex items-end justify-between">
                <p className="font-display text-xl font-black uppercase text-white leading-tight">{coachTips[1].fault}</p>
                <svg
                  width="18"
                  height="18"
                  viewBox="0 0 18 18"
                  fill="none"
                  style={{ transform: expandedTip === 1 ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }}
                >
                  <path d="M4 6l5 5 5-5" stroke="white" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </div>
            </div>
          </div>
        </button>
        {expandedTip === 1 && (
          <div className="p-4 animate-fade-in">
            <p className="text-xs text-[#7070a0] mb-3 leading-relaxed">{coachTips[1].cue}</p>
            <div className="flex gap-2 text-[10px]">
              <span className="px-2 py-1 rounded-lg text-[#22d3a5]" style={{ background: 'rgba(34,211,165,0.1)', border: '1px solid rgba(34,211,165,0.2)' }}>
                ↓ 37% en 4 semanas
              </span>
              <span className="px-2 py-1 rounded-lg text-[#7070a0]" style={{ background: '#1e1e32', border: '1px solid #2a2a44' }}>
                {coachTips[1].repsAffected} reps este mes
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
