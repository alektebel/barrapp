import { useEffect, useState } from 'react'
import { qualityTrend, personalBests, faultTrend, mockSessions, scoreColor, sessionAvg } from '../data/mock'

function LineChart({ data }: { data: { label: string; score: number }[] }) {
  const [ready, setReady] = useState(false)
  useEffect(() => { const t = setTimeout(() => setReady(true), 400); return () => clearTimeout(t) }, [])

  const W = 340
  const H = 110
  const pad = { t: 8, b: 24, l: 8, r: 8 }
  const innerW = W - pad.l - pad.r
  const innerH = H - pad.t - pad.b

  const min = Math.min(...data.map(d => d.score)) - 5
  const max = Math.max(...data.map(d => d.score)) + 5
  const range = max - min

  const points = data.map((d, i) => ({
    x: pad.l + (i / (data.length - 1)) * innerW,
    y: pad.t + innerH - ((d.score - min) / range) * innerH,
  }))

  const pathD = points.map((p, i) => `${i === 0 ? 'M' : 'L'}${p.x},${p.y}`).join(' ')
  const areaD = `${pathD} L${points[points.length - 1].x},${H - pad.b} L${points[0].x},${H - pad.b} Z`

  const tickIndices = [0, Math.floor(data.length / 2), data.length - 1]

  return (
    <svg width="100%" viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" style={{ overflow: 'visible' }}>
      <defs>
        <linearGradient id="lineGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#7c5dfa" stopOpacity="0.35" />
          <stop offset="100%" stopColor="#7c5dfa" stopOpacity="0.02" />
        </linearGradient>
        <clipPath id="chartClip">
          <rect
            x={pad.l}
            y={pad.t}
            width={ready ? innerW : 0}
            height={innerH}
            style={{ transition: 'width 1.2s cubic-bezier(0.4,0,0.2,1)' }}
          />
        </clipPath>
      </defs>

      {/* Grid */}
      {[0.25, 0.5, 0.75].map((t, i) => (
        <line
          key={i}
          x1={pad.l}
          y1={pad.t + innerH * t}
          x2={W - pad.r}
          y2={pad.t + innerH * t}
          stroke="#2a2a44"
          strokeWidth="1"
          strokeDasharray="3 4"
        />
      ))}

      {/* Area */}
      <path d={areaD} fill="url(#lineGrad)" clipPath="url(#chartClip)" />

      {/* Line */}
      <path
        d={pathD}
        fill="none"
        stroke="#7c5dfa"
        strokeWidth="2.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        clipPath="url(#chartClip)"
      />

      {/* Dots */}
      {ready && points.map((p, i) => (
        <circle key={i} cx={p.x} cy={p.y} r="3" fill="#a78bfa" />
      ))}

      {/* X labels */}
      {tickIndices.map(i => (
        <text
          key={i}
          x={points[i].x}
          y={H - 4}
          textAnchor="middle"
          fontSize="8"
          fill="#7070a0"
          fontFamily="'JetBrains Mono', monospace"
        >
          {data[i].label}
        </text>
      ))}
    </svg>
  )
}

function FaultBar({ fault, count, trend, color, max }: { fault: string; count: number; trend: number; color: string; max: number }) {
  const [ready, setReady] = useState(false)
  useEffect(() => { const t = setTimeout(() => setReady(true), 500); return () => clearTimeout(t) }, [])

  return (
    <div className="mb-3">
      <div className="flex items-center justify-between mb-1.5">
        <span className="text-xs text-[#f0eeff]">{fault}</span>
        <div className="flex items-center gap-2">
          <span className="font-mono-data text-[9px]" style={{ color }}>
            {trend < 0 ? `↓ ${Math.abs(trend)} reps` : `↑ ${trend} reps`}
          </span>
          <span className="font-mono-data text-[9px] text-[#7070a0]">{count}</span>
        </div>
      </div>
      <div className="h-1.5 rounded-full overflow-hidden" style={{ background: '#2a2a44' }}>
        <div
          className="h-full rounded-full transition-all duration-1000 ease-out"
          style={{ width: ready ? `${(count / max) * 100}%` : '0%', background: color }}
        />
      </div>
    </div>
  )
}

export default function Progress() {
  const maxFault = Math.max(...faultTrend.map(f => f.count))
  const last7Avg = Math.round(
    mockSessions.flatMap(s => s.sets.flatMap(set => set.reps)).slice(-50)
      .reduce((a, r) => a + r.score, 0) / 50
  )

  return (
    <div className="px-4 pb-6 space-y-4 pt-2">
      <div>
        <p className="font-mono-data text-[10px] text-[#7070a0] uppercase tracking-[0.18em]">BarrApp</p>
        <h1 className="font-display text-3xl font-black uppercase text-[#f0eeff] leading-none">PROGRESO</h1>
      </div>

      {/* Key stats */}
      <div className="grid grid-cols-3 gap-2">
        {[
          { label: 'Calidad media', value: '74', unit: 'pts', trend: '+16', trendGood: true },
          { label: 'Reps totales', value: '847', unit: '', trend: 'este mes', trendGood: true },
          { label: 'Mejor serie', value: '91', unit: 'pts', trend: '27 Ago', trendGood: true },
        ].map((s, i) => (
          <div
            key={i}
            className="rounded-2xl p-3 text-center animate-slide-up"
            style={{ background: '#161626', border: '1px solid #2a2a44', animationDelay: `${i * 80}ms` }}
          >
            <div className="font-display text-2xl font-black text-[#f0eeff] leading-none">
              {s.value}
              {s.unit && <span className="text-sm ml-0.5 text-[#7070a0]">{s.unit}</span>}
            </div>
            <p className="font-mono-data text-[8px] text-[#7070a0] uppercase mt-1">{s.label}</p>
            <p className="font-mono-data text-[8px] mt-0.5" style={{ color: s.trendGood ? '#22d3a5' : '#f43f5e' }}>
              {s.trend}
            </p>
          </div>
        ))}
      </div>

      {/* Quality trend chart */}
      <div
        className="rounded-2xl p-4 animate-slide-up delay-200"
        style={{ background: '#161626', border: '1px solid #2a2a44' }}
      >
        <div className="flex items-center justify-between mb-4">
          <div>
            <span className="font-mono-data text-[10px] text-[#7070a0] uppercase tracking-wider">CALIDAD · 30 DÍAS</span>
            <p className="font-display text-lg font-bold uppercase text-[#f0eeff] mt-0.5">Tendencia de técnica</p>
          </div>
          <div className="text-right">
            <span className="font-display text-2xl font-black" style={{ color: scoreColor(74) }}>74</span>
            <p className="font-mono-data text-[8px] text-[#22d3a5] mt-0.5">↑ +16 pts</p>
          </div>
        </div>
        <LineChart data={qualityTrend} />
      </div>

      {/* Personal bests */}
      <div
        className="rounded-2xl p-4 animate-slide-up delay-300"
        style={{ background: '#161626', border: '1px solid #2a2a44' }}
      >
        <span className="font-mono-data text-[10px] text-[#7070a0] uppercase tracking-wider block mb-3">
          RÉCORDS PERSONALES
        </span>
        {personalBests.map((pb, i) => (
          <div key={i} className="flex items-center justify-between py-2.5" style={{ borderBottom: i < personalBests.length - 1 ? '1px solid #2a2a44' : 'none' }}>
            <div>
              <p className="font-display text-base font-bold uppercase text-[#f0eeff]">{pb.exercise}</p>
              <p className="text-xs text-[#7070a0]">{pb.metric}</p>
            </div>
            <div className="text-right">
              <span
                className="font-display text-2xl font-black"
                style={{ color: '#a78bfa' }}
              >
                {pb.value}
                <span className="text-sm ml-0.5 text-[#7070a0]">{pb.unit}</span>
              </span>
              <p className="font-mono-data text-[8px] text-[#7070a0]">{pb.date}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Fault tracker */}
      <div
        className="rounded-2xl p-4 animate-slide-up delay-400"
        style={{ background: '#161626', border: '1px solid #2a2a44' }}
      >
        <div className="flex items-center justify-between mb-4">
          <span className="font-mono-data text-[10px] text-[#7070a0] uppercase tracking-wider">ERRORES · ÚLTIMAS 4 SEMANAS</span>
          <span className="font-mono-data text-[9px] text-[#22d3a5]">↓ mejorando</span>
        </div>
        {faultTrend.map((f, i) => (
          <FaultBar key={i} fault={f.fault} count={f.count} trend={f.trend} color={f.color} max={maxFault} />
        ))}
        <p className="text-[9px] text-[#7070a0] mt-2">
          Los números bajan semana a semana — sigue filmando para mantener la tendencia.
        </p>
      </div>

      {/* Session history */}
      <div
        className="rounded-2xl p-4 animate-slide-up delay-500"
        style={{ background: '#161626', border: '1px solid #2a2a44' }}
      >
        <span className="font-mono-data text-[10px] text-[#7070a0] uppercase tracking-wider block mb-3">HISTORIAL</span>
        {mockSessions.map((s, i) => {
          const avg = sessionAvg(s)
          return (
            <div
              key={s.id}
              className="flex items-center justify-between py-2.5"
              style={{ borderBottom: i < mockSessions.length - 1 ? '1px solid #2a2a44' : 'none' }}
            >
              <div className="flex items-center gap-3">
                <div
                  className="w-8 h-8 rounded-xl flex items-center justify-center"
                  style={{ background: 'rgba(124,93,250,0.12)', border: '1px solid rgba(124,93,250,0.2)' }}
                >
                  <span className="font-display text-xs font-bold text-[#a78bfa]">
                    {s.sets.flatMap(set => set.reps).length}
                  </span>
                </div>
                <div>
                  <p className="font-display text-sm font-bold uppercase text-[#f0eeff]">{s.exercise}</p>
                  <p className="text-[10px] text-[#7070a0]">{s.date} · {s.sets.length} series</p>
                </div>
              </div>
              <div className="text-right">
                <span className="font-display text-xl font-black" style={{ color: scoreColor(avg) }}>{avg}</span>
                <p className="font-mono-data text-[8px] text-[#7070a0]">pts</p>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
