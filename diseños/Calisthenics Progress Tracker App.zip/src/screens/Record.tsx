import { useEffect, useRef, useState } from 'react'
import { mockSessions, scoreColor, scoreLabel, sessionAvg, setAvg } from '../data/mock'
import type { Session } from '../data/mock'

type Phase = 'idle' | 'analyzing' | 'results'

const analyzeSteps = [
  'Detectando movimiento…',
  'Contando repeticiones…',
  'Analizando técnica…',
  'Calculando puntuaciones…',
]

function ScoreRing({ score, size = 52, stroke = 5 }: { score: number; size?: number; stroke?: number }) {
  const [filled, setFilled] = useState(false)
  const r = (size - stroke * 2) / 2
  const circ = 2 * Math.PI * r
  const offset = circ - (score / 100) * circ

  useEffect(() => {
    const t = setTimeout(() => setFilled(true), 100)
    return () => clearTimeout(t)
  }, [])

  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} style={{ transform: 'rotate(-90deg)' }}>
      <circle
        cx={size / 2}
        cy={size / 2}
        r={r}
        fill="none"
        stroke="#2a2a44"
        strokeWidth={stroke}
        strokeLinecap="round"
      />
      <circle
        cx={size / 2}
        cy={size / 2}
        r={r}
        fill="none"
        stroke={scoreColor(score)}
        strokeWidth={stroke}
        strokeLinecap="round"
        strokeDasharray={circ}
        strokeDashoffset={filled ? offset : circ}
        style={{ transition: 'stroke-dashoffset 1.1s cubic-bezier(0.4,0,0.2,1)' }}
      />
    </svg>
  )
}

function RepCard({ rep, delay }: { rep: { num: number; score: number; faults: string[] }; delay: number }) {
  return (
    <div
      className="flex items-center gap-3 p-3 rounded-xl animate-slide-up"
      style={{
        background: '#1e1e32',
        animationDelay: `${delay}ms`,
        border: '1px solid #2a2a44',
      }}
    >
      <div className="relative flex-shrink-0">
        <ScoreRing score={rep.score} size={48} stroke={4} />
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="font-mono-data text-[11px] font-semibold" style={{ color: scoreColor(rep.score) }}>
            {rep.score}
          </span>
        </div>
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-1">
          <span className="font-mono-data text-[10px] text-[#7070a0] uppercase">Rep {rep.num}</span>
          <span className="font-mono-data text-[9px]" style={{ color: scoreColor(rep.score) }}>
            {scoreLabel(rep.score)}
          </span>
        </div>
        {rep.faults.length === 0 ? (
          <div className="flex items-center gap-1">
            <div className="w-1.5 h-1.5 rounded-full bg-teal" style={{ background: '#22d3a5' }} />
            <span className="text-[10px] text-[#22d3a5]">Rep limpia</span>
          </div>
        ) : (
          <div className="flex flex-wrap gap-1">
            {rep.faults.map((f, i) => (
              <span
                key={i}
                className="text-[9px] px-1.5 py-0.5 rounded-md"
                style={{ background: 'rgba(245,158,11,0.12)', color: '#f59e0b', border: '1px solid rgba(245,158,11,0.2)' }}
              >
                {f}
              </span>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

function AnalyzingOverlay({ stepIdx }: { stepIdx: number }) {
  return (
    <div className="flex flex-col items-center justify-center flex-1 px-8 text-center">
      <div className="relative mb-8">
        <div
          className="w-24 h-24 rounded-full flex items-center justify-center"
          style={{ background: 'rgba(124,93,250,0.1)', border: '2px solid rgba(124,93,250,0.3)' }}
        >
          <div className="animate-pulse-ring absolute inset-0 rounded-full" style={{ border: '2px solid rgba(124,93,250,0.4)' }} />
          <svg width="40" height="40" viewBox="0 0 40 40" fill="none">
            <rect x="4" y="12" width="32" height="22" rx="3" stroke="#7c5dfa" strokeWidth="2" fill="none" />
            <path d="M4 17h32" stroke="#7c5dfa" strokeWidth="1.5" opacity="0.4" />
            <circle cx="20" cy="25" r="5" fill="rgba(124,93,250,0.3)" stroke="#a78bfa" strokeWidth="1.5" />
            <circle cx="20" cy="25" r="2" fill="#a78bfa" />
          </svg>
        </div>
        <div
          className="absolute inset-0 rounded-full animate-pulse-ring"
          style={{ border: '1px solid rgba(124,93,250,0.25)', animationDelay: '300ms' }}
        />
      </div>
      <p className="font-mono-data text-[10px] text-[#7c5dfa] uppercase tracking-[0.2em] mb-2">ANALIZANDO</p>
      <p className="font-display text-2xl font-bold uppercase text-[#f0eeff] mb-6">
        {analyzeSteps[stepIdx]}
      </p>
      <div className="flex gap-2">
        {analyzeSteps.map((_, i) => (
          <div
            key={i}
            className="h-1 rounded-full transition-all duration-500"
            style={{
              width: i <= stepIdx ? 20 : 6,
              background: i <= stepIdx ? '#7c5dfa' : '#2a2a44',
            }}
          />
        ))}
      </div>
    </div>
  )
}

export default function Record({ onDone }: { onDone: () => void }) {
  const [phase, setPhase] = useState<Phase>('idle')
  const [stepIdx, setStepIdx] = useState(0)
  const [results, setResults] = useState<Session | null>(null)
  const [activeSet, setActiveSet] = useState(0)
  const fileRef = useRef<HTMLInputElement>(null)

  function startAnalysis() {
    setPhase('analyzing')
    setStepIdx(0)
    let i = 0
    const iv = setInterval(() => {
      i++
      if (i < analyzeSteps.length) {
        setStepIdx(i)
      } else {
        clearInterval(iv)
        setResults(mockSessions[0])
        setPhase('results')
      }
    }, 900)
  }

  const session = results || mockSessions[0]
  const currentSet = session.sets[activeSet]
  const avg = results ? sessionAvg(session) : null
  const allFaults = session.sets.flatMap(s => s.reps).flatMap(r => r.faults)
  const faultMap: Record<string, number> = {}
  allFaults.forEach(f => { faultMap[f] = (faultMap[f] || 0) + 1 })

  return (
    <div className="flex flex-col h-full">
      <div className="px-4 pt-3 pb-2 flex-shrink-0">
        <p className="font-mono-data text-[10px] text-[#7070a0] uppercase tracking-[0.18em]">BarrApp</p>
        <h1 className="font-display text-3xl font-black uppercase text-[#f0eeff] leading-none">
          {phase === 'results' ? 'ANÁLISIS' : 'GRABAR SET'}
        </h1>
      </div>

      {phase === 'idle' && (
        <div className="flex-1 flex flex-col px-4 pb-6">
          {/* Record button */}
          <div className="flex flex-col items-center justify-center flex-1">
            <div className="relative mb-6">
              <div
                className="absolute inset-0 rounded-full animate-pulse-ring"
                style={{ background: 'rgba(124,93,250,0.1)', transform: 'scale(1.25)' }}
              />
              <button
                onClick={startAnalysis}
                className="w-28 h-28 rounded-full flex items-center justify-center relative z-10 active:scale-95 transition-transform"
                style={{ background: 'linear-gradient(135deg, #7c5dfa, #a78bfa)' }}
              >
                <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                  <div className="w-5 h-5 rounded-full bg-white" />
                </div>
              </button>
            </div>
            <p className="font-display text-lg font-bold uppercase text-[#f0eeff] mb-1">GRABAR UN SET</p>
            <p className="text-xs text-[#7070a0] text-center mb-8 max-w-48">
              Coloca el teléfono de lado, pulsa grabar y empieza tu serie
            </p>

            <div className="flex items-center gap-3 w-full mb-6">
              <div className="flex-1 h-px" style={{ background: '#2a2a44' }} />
              <span className="font-mono-data text-[10px] text-[#7070a0]">O</span>
              <div className="flex-1 h-px" style={{ background: '#2a2a44' }} />
            </div>

            <input ref={fileRef} type="file" accept="video/*" className="hidden" onChange={startAnalysis} />
            <button
              onClick={() => fileRef.current?.click()}
              className="w-full py-3.5 rounded-2xl font-display text-lg font-bold uppercase tracking-widest active:scale-[0.98] transition-transform"
              style={{ background: '#161626', border: '1.5px solid #2a2a44', color: '#a78bfa' }}
            >
              SUBIR VÍDEO
            </button>
          </div>

          {/* Recent */}
          <div className="rounded-2xl p-4 mt-2" style={{ background: '#161626', border: '1px solid #2a2a44' }}>
            <span className="font-mono-data text-[10px] text-[#7070a0] uppercase tracking-wider">ÚLTIMA SESIÓN ANALIZADA</span>
            <div className="flex items-center justify-between mt-2">
              <div>
                <p className="font-display text-base font-bold uppercase text-[#f0eeff]">Pull-up · 3 series</p>
                <p className="text-xs text-[#7070a0]">Hace 2 días · 19 reps</p>
              </div>
              <span
                className="font-display text-2xl font-black"
                style={{ color: scoreColor(74) }}
              >
                74
              </span>
            </div>
          </div>
        </div>
      )}

      {phase === 'analyzing' && <AnalyzingOverlay stepIdx={stepIdx} />}

      {phase === 'results' && avg !== null && (
        <div className="flex-1 overflow-y-auto px-4 pb-6">
          {/* Summary header */}
          <div
            className="rounded-2xl p-4 mb-4 animate-slide-up"
            style={{ background: '#161626', border: '1.5px solid rgba(124,93,250,0.3)' }}
          >
            <div className="flex items-center gap-4">
              <div className="relative">
                <ScoreRing score={avg} size={72} stroke={6} />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <span className="font-mono-data text-lg font-semibold" style={{ color: scoreColor(avg) }}>
                      {avg}
                    </span>
                  </div>
                </div>
              </div>
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-mono-data text-[10px] text-[#7c5dfa] uppercase tracking-wider">MOVIMIENTO</span>
                </div>
                <p className="font-display text-2xl font-black uppercase text-[#f0eeff] leading-none">{session.exercise}</p>
                <p className="text-xs text-[#7070a0] mt-0.5">
                  {session.sets.length} series · {session.sets.flatMap(s => s.reps).length} reps en total
                </p>
                <p className="font-mono-data text-[10px] mt-1" style={{ color: scoreColor(avg) }}>
                  {scoreLabel(avg)} — {avg >= 75 ? 'por encima de tu media' : 'algo por debajo de tu media'}
                </p>
              </div>
            </div>
          </div>

          {/* Faults summary */}
          {Object.keys(faultMap).length > 0 && (
            <div
              className="rounded-2xl p-4 mb-4 animate-slide-up delay-100"
              style={{ background: '#161626', border: '1px solid #2a2a44' }}
            >
              <span className="font-mono-data text-[10px] text-[#7070a0] uppercase tracking-wider block mb-3">
                ERRORES DETECTADOS
              </span>
              {Object.entries(faultMap)
                .sort((a, b) => b[1] - a[1])
                .map(([fault, count], i) => (
                  <div key={i} className="flex items-center gap-3 mb-2">
                    <div className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: '#f59e0b' }} />
                    <span className="text-xs text-[#f0eeff] flex-1">{fault}</span>
                    <span className="font-mono-data text-[9px] text-[#f59e0b]">{count} reps</span>
                  </div>
                ))}
            </div>
          )}

          {/* Set tabs */}
          <div className="flex gap-2 mb-3 animate-slide-up delay-200">
            {session.sets.map((set, si) => {
              const sa = setAvg(set)
              return (
                <button
                  key={si}
                  onClick={() => setActiveSet(si)}
                  className="flex-1 py-2 rounded-xl font-mono-data text-[10px] uppercase tracking-wider transition-all"
                  style={{
                    background: activeSet === si ? '#7c5dfa' : '#161626',
                    color: activeSet === si ? 'white' : '#7070a0',
                    border: `1px solid ${activeSet === si ? '#7c5dfa' : '#2a2a44'}`,
                  }}
                >
                  Ser {si + 1} · {sa}
                </button>
              )
            })}
          </div>

          {/* Rep cards */}
          <div className="space-y-2 mb-4">
            {currentSet.reps.map((rep, i) => (
              <RepCard key={`${activeSet}-${i}`} rep={rep} delay={i * 60} />
            ))}
          </div>

          <button
            onClick={onDone}
            className="w-full py-4 rounded-2xl font-display text-xl font-black uppercase tracking-widest text-white active:scale-[0.98] transition-transform"
            style={{ background: 'linear-gradient(135deg, #7c5dfa, #a78bfa)' }}
          >
            GUARDAR SESIÓN (+180 XP)
          </button>
        </div>
      )}
    </div>
  )
}
