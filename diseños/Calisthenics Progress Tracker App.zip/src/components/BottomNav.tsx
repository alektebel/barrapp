import React from 'react'
import type { Tab } from '../App'

const tabs: { id: Tab; label: string; icon: (active: boolean) => React.ReactElement }[] = [
  {
    id: 'home',
    label: 'Inicio',
    icon: (active) => (
      <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
        <path
          d="M3 9.5L11 3l8 6.5V19a1 1 0 01-1 1H4a1 1 0 01-1-1V9.5z"
          stroke={active ? '#a78bfa' : '#7070a0'}
          strokeWidth="1.7"
          fill={active ? 'rgba(124,93,250,0.15)' : 'none'}
          strokeLinejoin="round"
        />
        <path d="M8 20v-8h6v8" stroke={active ? '#a78bfa' : '#7070a0'} strokeWidth="1.7" strokeLinejoin="round" />
      </svg>
    ),
  },
  {
    id: 'record',
    label: 'Grabar',
    icon: (active) => (
      <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
        <circle
          cx="11"
          cy="11"
          r="8.5"
          stroke={active ? '#a78bfa' : '#7070a0'}
          strokeWidth="1.7"
          fill={active ? 'rgba(124,93,250,0.15)' : 'none'}
        />
        <circle cx="11" cy="11" r="4" fill={active ? '#a78bfa' : '#7070a0'} />
      </svg>
    ),
  },
  {
    id: 'progress',
    label: 'Progreso',
    icon: (active) => (
      <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
        <polyline
          points="2,16 7,10 11,13 16,6 20,9"
          stroke={active ? '#a78bfa' : '#7070a0'}
          strokeWidth="1.7"
          fill="none"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <circle cx="20" cy="9" r="1.5" fill={active ? '#a78bfa' : '#7070a0'} />
      </svg>
    ),
  },
  {
    id: 'coach',
    label: 'Coach',
    icon: (active) => (
      <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
        <circle
          cx="11"
          cy="7.5"
          r="3.5"
          stroke={active ? '#a78bfa' : '#7070a0'}
          strokeWidth="1.7"
          fill={active ? 'rgba(124,93,250,0.15)' : 'none'}
        />
        <path
          d="M3.5 19c0-4.14 3.36-7.5 7.5-7.5s7.5 3.36 7.5 7.5"
          stroke={active ? '#a78bfa' : '#7070a0'}
          strokeWidth="1.7"
          strokeLinecap="round"
          fill="none"
        />
      </svg>
    ),
  },
]

export default function BottomNav({ tab, onTab }: { tab: Tab; onTab: (t: Tab) => void }) {
  return (
    <div
      className="flex-shrink-0 flex items-end justify-around px-2 pb-5 pt-2"
      style={{ background: 'linear-gradient(to top, #0b0b12 80%, transparent)', borderTop: '1px solid #2a2a44' }}
    >
      {tabs.map((t) => {
        const active = tab === t.id
        return (
          <button
            key={t.id}
            onClick={() => onTab(t.id)}
            className="flex flex-col items-center gap-1 px-4 py-1 relative"
          >
            {t.icon(active)}
            <span
              className="text-[9px] font-mono-data uppercase tracking-wider"
              style={{ color: active ? '#a78bfa' : '#7070a0' }}
            >
              {t.label}
            </span>
            {active && (
              <div
                className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full"
                style={{ background: '#7c5dfa' }}
              />
            )}
          </button>
        )
      })}
    </div>
  )
}
