import { useState } from 'react'
import Onboarding from './screens/Onboarding'
import Home from './screens/Home'
import Record from './screens/Record'
import Progress from './screens/Progress'
import Coach from './screens/Coach'
import BottomNav from './components/BottomNav'

export type Tab = 'home' | 'record' | 'progress' | 'coach'

export interface Profile {
  name: string
  exercise: string
  goal: string
  level: string
}

export default function App() {
  const [profile, setProfile] = useState<Profile | null>(null)
  const [tab, setTab] = useState<Tab>('home')

  if (!profile) {
    return (
      <div className="flex h-full items-center justify-center" style={{ background: '#0b0b12' }}>
        <div className="w-full max-w-[430px] h-full overflow-hidden relative" style={{ background: '#0b0b12' }}>
          <Onboarding onComplete={(p) => { setProfile(p); setTab('home') }} />
        </div>
      </div>
    )
  }

  return (
    <div className="flex h-full items-center justify-center" style={{ background: '#06060d' }}>
      <div
        className="w-full max-w-[430px] h-full flex flex-col overflow-hidden relative"
        style={{ background: '#0b0b12' }}
      >
        {/* Fake status bar */}
        <div
          className="flex-shrink-0 flex justify-between items-center px-5 pt-3 pb-1"
          style={{ background: '#0b0b12' }}
        >
          <span className="font-mono-data text-[11px] text-[#7070a0]">9:41</span>
          <div className="flex gap-1.5 items-center">
            {/* Signal */}
            <svg width="16" height="12" viewBox="0 0 16 12" fill="none">
              <rect x="0" y="8" width="3" height="4" rx="0.5" fill="#7070a0" />
              <rect x="4.5" y="5" width="3" height="7" rx="0.5" fill="#7070a0" />
              <rect x="9" y="2" width="3" height="10" rx="0.5" fill="#7070a0" />
              <rect x="13.5" y="0" width="2.5" height="12" rx="0.5" fill="#7070a0" />
            </svg>
            {/* Battery */}
            <div className="flex items-center gap-0.5">
              <div
                className="w-5 h-2.5 rounded-[3px] border relative flex items-center px-0.5"
                style={{ borderColor: '#7070a0' }}
              >
                <div
                  className="h-1.5 rounded-[1.5px]"
                  style={{ width: '65%', background: '#7070a0' }}
                />
              </div>
              <div
                className="w-0.5 h-1 rounded-r-sm"
                style={{ background: '#7070a0' }}
              />
            </div>
          </div>
        </div>

        {/* Scrollable content area */}
        <div className="flex-1 overflow-y-auto overflow-x-hidden">
          {tab === 'home' && <Home profile={profile} />}
          {tab === 'record' && <Record onDone={() => setTab('home')} />}
          {tab === 'progress' && <Progress />}
          {tab === 'coach' && <Coach exercise={profile.exercise} />}
        </div>

        {/* Bottom nav */}
        <BottomNav tab={tab} onTab={setTab} />
      </div>
    </div>
  )
}
